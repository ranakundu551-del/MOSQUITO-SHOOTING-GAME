MOSQUITO SHOOTING GAME - Android APK project

এই ZIP-এ Android Studio project এবং GitHub Actions workflow আছে।
APK এখনো build করা হয়নি। GitHub-এ project upload করলে Actions থেকে APK তৈরি হবে।

GitHub-এ ব্যবহার:
1. নতুন repository তৈরি করো: MOSQUITO-SHOOTING-GAME
2. এই ZIP extract করে ভেতরের সব ফাইল repository-র root-এ upload করো (app, .github, build.gradle, settings.gradle, gradle.properties)।
3. Commit changes করো।
4. GitHub repository > Actions > Build Mosquito Shooting APK > Run workflow।
5. Build শেষ হলে workflow run-এর নিচে Artifacts থেকে MosquitoShooting-debug-APK ডাউনলোড করো।
6. ZIP extract করে app-debug.apk ফোনে install করো।

এটি debug APK; Play Store release-এর জন্য আলাদা signed release build দরকার।
