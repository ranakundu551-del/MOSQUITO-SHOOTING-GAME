MOSQUITO SHOOTING GAME - playable mobile browser prototype

How to play:
1. Open index.html in Chrome (or upload the folder to GitHub Pages).
2. Tap “খেলা শুরু”.
3. Tap mosquitoes to shoot them. Each hit gives 10 points.
4. First and second mosquito arrivals trigger two separate clean Bengali voice lines.
5. Shooting uses a short synthesized sound. Mosquito buzzing is intentionally not included.

This is a browser prototype, not an APK yet. To make an Android APK, this project needs to be wrapped in an Android WebView/Capacitor project and built with Android Studio. The reference video is a phone-recorded view with the game screen small, so this is a starter interpretation rather than a pixel-perfect clone.
